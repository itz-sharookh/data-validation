package com.validation.entity;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Document(collection = "new_user")
@Data
@Builder
public class NewUser {
	
	@Id
	private ObjectId id;
	private int name;
	private String dateOfBirth;
	private String fullName;
}
