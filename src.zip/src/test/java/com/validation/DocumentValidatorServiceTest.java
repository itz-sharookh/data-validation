package com.validation;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bson.types.ObjectId;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;

import com.validation.entity.NewUser;
import com.validation.entity.OldUser;
import com.validation.service.DocumentValidatorService;

import de.flapdoodle.embed.mongo.MongodExecutable;
import de.flapdoodle.embed.mongo.MongodProcess;
import de.flapdoodle.embed.mongo.MongodStarter;
import de.flapdoodle.embed.mongo.config.MongodConfig;
import de.flapdoodle.embed.mongo.config.Net;
import de.flapdoodle.embed.mongo.distribution.Version;

@ActiveProfiles("test")
@SpringBootTest
@DirtiesContext
public class DocumentValidatorServiceTest {

	@Autowired
	private MongoTemplate mongoTemplate;
	private static MongodProcess mongodProcess;

	@Autowired
	private DocumentValidatorService documentValidatorService;

	@BeforeAll
	static void setup() {
		try {
			MongodConfig mongodConfig = MongodConfig.builder().version(Version.Main.PRODUCTION)
					.net(new Net("localhost", 27017, false)).build();
			MongodStarter starter = MongodStarter.getDefaultInstance();
			MongodExecutable mongodExecutable = starter.prepare(mongodConfig);
			mongodProcess = mongodExecutable.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void testCreateCollection() {
		mongoTemplate.insertAll(generateOldUserTestData());
		mongoTemplate.insertAll(generateNewUserTestData());
		Map<String, List<String>> result = documentValidatorService.checkFieldAdditionAndRemoval("old_user",
				"new_user");
		assertNotNull(result);
	}

	@Test
	void testAnalyzeSchema() {
		mongoTemplate.insertAll(generateOldUserTestData());
		mongoTemplate.insertAll(generateNewUserTestData());
		Map<String, List<String>> results = documentValidatorService.analyzeSchema("old_user", "new_user");
		assertNotNull(results);
	}

	@Test
	void testvalidateDocuments() {
		mongoTemplate.insertAll(generateOldUserTestData());
		mongoTemplate.insertAll(generateNewUserTestData());
		int result = documentValidatorService.validateDocuments("old_user", "new_user");
		assertEquals(1, result);
	}

	@AfterAll
	static void cleanup() {
		if (mongodProcess != null) {
			mongodProcess.stop();
		}
	}

	private List<OldUser> generateOldUserTestData() {
		List<OldUser> users = new ArrayList<>();
		OldUser user1 = OldUser.builder().age(24).id(new ObjectId("507f1f77bcf86cd799439011")).name("sharookh").build();
		OldUser user2 = OldUser.builder().age(25).id(new ObjectId("507f1f77bcf86cd799439012")).name("sharookh1")
				.build();
		OldUser user3 = OldUser.builder().age(27).id(new ObjectId("507f1f77bcf86cd799439013")).name("sharook3").build();
		users.add(user1);
		users.add(user2);
		users.add(user3);
		return users;
	}

	private List<NewUser> generateNewUserTestData() {
		List<NewUser> users = new ArrayList<>();
		NewUser user1 = NewUser.builder().id(new ObjectId("507f1f77bcf86cd799439011")).name(345)
				.fullName("Sharookh Ahmed Shaik").dateOfBirth("14/05/1999").build();
		NewUser user2 = NewUser.builder().id(new ObjectId("507f1f77bcf86cd799439012")).name(346)
				.fullName("Sharookh Ahmed Shaik").dateOfBirth("18/07/2000").build();
		NewUser user3 = NewUser.builder().id(new ObjectId("507f1f77bcf86cd799439013")).name(347)
				.fullName("Sharookh Ahmed Shaik").dateOfBirth("01/11/2002").build();
		users.add(user1);
		users.add(user2);
		users.add(user3);
		return users;
	}
}
