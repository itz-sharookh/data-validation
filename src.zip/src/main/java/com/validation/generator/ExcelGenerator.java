package com.validation.generator;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

@Component
public class ExcelGenerator {

	public void generateExcel(List<Map<String, List<String>>> sheetTypes, String fileName,
			List<String> sheetNames) throws IOException {
		Workbook workbook = new XSSFWorkbook();
		int sheetNumber = 0;
		for (String sheet : sheetNames) {
			if (sheet.equals("Field Analysis")) {
				createExcel(workbook, combineValues(sheetNumber, sheetTypes), sheet, "Document Id", "Added Field",
						"Removed Field", "Added Field Is:", "Removed Field Is:");
			} else {
				createExcel(workbook, combineValues(sheetNumber, sheetTypes), sheet, "Field", "Old DataType",
						"New DataType", "Old Datatype Is:", "New Datatype Is:");
			}
			sheetNumber++;
		}
		try (FileOutputStream fileOut = new FileOutputStream(fileName)) {
			workbook.write(fileOut);
		} finally {
			workbook.close();
		}
	}

	private void createExcel(Workbook workbook, Map<String, List<String>> map, String sheetName, String headerValue,
			String key1, String key2, String filter1, String filter2) {
		Sheet sheet = workbook.createSheet(sheetName);

		Row headerRow = sheet.createRow(0);
		Cell headerKey = headerRow.createCell(0);
		headerKey.setCellValue(headerValue);
		Cell headerValue1 = headerRow.createCell(1);
		headerValue1.setCellValue(key1);
		Cell headerValue2 = headerRow.createCell(2);
		headerValue2.setCellValue(key2);

		int rowIndex = 1;
		for (Map.Entry<String, List<String>> entry : map.entrySet()) {
			String key = entry.getKey();
			List<String> values = entry.getValue();

			Row row = sheet.createRow(rowIndex++);
			Cell cellKey = row.createCell(0);
			cellKey.setCellValue(key);

			String AddedValue = values.stream().filter(val -> val.contains(filter1)).map(val -> {
				String[] arr = val.split(":");
				return arr[1];
			}).collect(Collectors.joining(", "));
			Cell cellKey1 = row.createCell(1);
			cellKey1.setCellValue(AddedValue);

			String removedValue = values.stream().filter(val -> val.contains(filter2)).map(val -> {
				String[] arr = val.split(":");
				return arr[1];
			}).collect(Collectors.joining(", "));

			Cell cellKey2 = row.createCell(2);
			cellKey2.setCellValue(removedValue);
		}
	}

	private Map<String, List<String>> combineValues(int index, List<Map<String, List<String>>> sheet) {
		return sheet.get(index);
	}
}
