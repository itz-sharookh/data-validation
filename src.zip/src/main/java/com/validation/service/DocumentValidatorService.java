package com.validation.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.validation.generator.ExcelGenerator;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service("documentValidatorService")
public class DocumentValidatorService {

	private final MongoTemplate mongoTemplate;
	private final ExcelGenerator generator;
	private static final String FIELD_ANALYSIS = "Field Analysis";
	private static final String SCHEMA_ANALYSIS = "Schema Analysis";

	public int validateDocuments(String oldCollectName, String newCollectName) {
		CompletableFuture<Map<String, List<String>>> fieldAdditionFuture = CompletableFuture
				.supplyAsync(() -> checkFieldAdditionAndRemoval(oldCollectName, newCollectName));

		CompletableFuture<Map<String, List<String>>> analyzeSchemaFuture = CompletableFuture
				.supplyAsync(() -> analyzeSchema(oldCollectName, newCollectName));

		try {
			Map<String, List<String>> fieldAddition = fieldAdditionFuture.get();
			Map<String, List<String>> analyzeSchema = analyzeSchemaFuture.get();
			
			List<Map<String, List<String>>> sheetData = List.of(fieldAddition, analyzeSchema);
			List<String> sheetNames = List.of(FIELD_ANALYSIS, SCHEMA_ANALYSIS);
			generator.generateExcel(sheetData, "C:\\Work Related\\POC\\Test.xlsx", sheetNames);
			
		} catch (IOException | InterruptedException  | ExecutionException ex) {
			ex.printStackTrace();
			return 0;
		} 
		
		return 1;
	}

	public Map<String, List<String>> checkFieldAdditionAndRemoval(String oldCollectName, String newCollectName) {
		MongoCollection<Document> oldCollection = mongoTemplate.getCollection(oldCollectName);
		int skipCount = 0;
		int limitCount = 10;
		FindIterable<Document> oldDocuments = oldCollection.find().skip(skipCount).limit(limitCount);
		MongoCollection<Document> newCollection = mongoTemplate.getCollection(newCollectName);
		Document query = new Document("_id", new Document("$in", getIds(oldDocuments)));
		FindIterable<Document> newDocuments = newCollection.find(query);

		List<Document> results = new ArrayList<>();
		newDocuments.into(results);
		Map<String, List<String>> fieldMap = new HashMap<>();
		for (Document document : oldDocuments) {
			Optional<Document> optionalDoc = results.stream().filter(doc -> doc.get("_id").equals(document.get("_id")))
					.findAny();
			if (optionalDoc.isEmpty()) {
				continue;
			}

			Document newDoc = optionalDoc.get();
			Set<String> oldFields = document.keySet();
			Set<String> newFields = newDoc.keySet();
			List<String> fieldUpdates = new ArrayList<>();
			newFields.stream().filter(field -> !oldFields.contains(field)).forEach(field -> {
				if(!fieldUpdates.contains(field)) {
					fieldUpdates.add("Added Field Is:" + field);
				}
			});

			oldFields.stream().filter(field -> !newFields.contains(field)).forEach(field -> {
				if(!fieldUpdates.contains(field)) {
					fieldUpdates.add("Removed Field Is:" + field);
				}
			});
			String oldDocId = document.get("_id").toString();
			if (fieldMap.containsKey(oldDocId)) {
				List<String> existingList = fieldMap.get(oldDocId);
				existingList.addAll(fieldUpdates);
				fieldMap.put(oldDocId, existingList);
			} else {
				fieldMap.put(oldDocId, fieldUpdates);
			}
		}
		return fieldMap;
	}

	public Map<String, List<String>> analyzeSchema(String oldCollectionName, String newCollectionName) {
		List<Document> newDocList = new ArrayList<>();
		List<Document> oldDocList = new ArrayList<>();
		AggregateIterable<Document> oldResult = mongoTemplate.getCollection(oldCollectionName)
				.aggregate(Arrays.asList(
						new Document("$project", new Document("fields", new Document("$objectToArray", "$$ROOT"))),
						new Document("$unwind", "$fields"),
						new Document("$project",
								new Document("field", "$fields.k").append("type", new Document("$type", "$fields.v"))),
						new Document("$group",
								new Document("_id", "$field").append("types", new Document("$addToSet", "$type")))));

		AggregateIterable<Document> newResult = mongoTemplate.getCollection(newCollectionName)
				.aggregate(Arrays.asList(
						new Document("$project", new Document("fields", new Document("$objectToArray", "$$ROOT"))),
						new Document("$unwind", "$fields"),
						new Document("$project",
								new Document("field", "$fields.k").append("type", new Document("$type", "$fields.v"))),
						new Document("$group",
								new Document("_id", "$field").append("types", new Document("$addToSet", "$type")))));
		oldResult.into(oldDocList);
		newResult.into(newDocList);

		return compareSchema(oldDocList, newDocList);
	}

	private Map<String, List<String>> compareSchema(List<Document> oldDocList, List<Document> newDocList) {
		Map<String, List<String>> schemaMap = new HashMap<>();

		for (Document doc : oldDocList) {
			String field = doc.getString("_id");
			if (field.equals("_class")) {
				continue;
			}
			newDocList.stream().filter(doc1 -> doc1.getString("_id").equals(field)).forEach(filter -> {
				List<String> al = new ArrayList<>();
				al.add("New Datatype Is:" + filter.get("types").toString());
				al.add("Old Datatype Is:" + doc.get("types").toString());
				schemaMap.put(filter.getString("_id"), al);
			});
		}

		oldDocList.stream().filter(
				doc1 -> (!schemaMap.containsKey(doc1.getString("_id")) && !doc1.getString("_id").equals("_class")))
				.forEach(doc1 -> {
					List<String> al = new ArrayList<>();
					al.add("Old Datatype Is:" + doc1.get("types").toString());
					schemaMap.put(doc1.getString("_id"), al);
				});

		newDocList.stream().filter(
				doc1 -> (!schemaMap.containsKey(doc1.getString("_id")) && !doc1.getString("_id").equals("_class")))
				.forEach(doc1 -> {
					List<String> al = new ArrayList<>();
					al.add("New Datatype Is:" + doc1.get("types").toString());
					schemaMap.put(doc1.getString("_id"), al);
				});

		System.out.println(schemaMap);
		return schemaMap;
	}

	private List<ObjectId> getIds(FindIterable<Document> docs) {
		List<ObjectId> docIds = new ArrayList<>();
		for (Document doc : docs) {
			Object id = doc.get("_id");
			docIds.add(new ObjectId(id.toString()));
		}
		return docIds;
	}
}
