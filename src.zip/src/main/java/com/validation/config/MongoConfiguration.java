package com.validation.config;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

@Configuration
public class MongoConfiguration {

	@Value("${spring.data.mongodb.uri}")
	private String mongoUri;

	@Value("${spring.data.mongodb.database}")
	private String databaseName;

	@Bean
	MongoTemplate mongoTemplate() {
		return new MongoTemplate(mongoConnectionFactory());
	}

	@Bean
	MongoDatabaseFactory mongoConnectionFactory() {
		return new SimpleMongoClientDatabaseFactory(clientConfig(), databaseName);
	}
	
	@Bean
	MongoClient clientConfig() {
		MongoClientSettings.Builder builder = MongoClientSettings.builder();
		builder.applyToConnectionPoolSettings(build -> {
			build.minSize(0);
			build.maxSize(8);
			build.maxConnectionIdleTime(1, TimeUnit.MILLISECONDS);
		});
		builder.applyConnectionString(new ConnectionString(mongoUri));
		MongoClientSettings settings = builder.build();
		return MongoClients.create(settings);
	}

}
